# MobileTechnologies-Lab1-TicTacToe
<img src="https://github.com/AlexanderDemchik/MobileTechnologies-Lab1-TicTacToe/raw/master/example.jpg" width="250" height="400" />

# MobileTechnologies-Lab2
<img src="https://github.com/AlexanderDemchik/MobileTechnologies-Lab1-TicTacToe/raw/master/lab2-example.jpg" width="250" height="400" />

# MobileTechnologies-Lab3
<img src="https://github.com/AlexanderDemchik/MobileTechnologies-Lab1-TicTacToe/raw/master/lab3-1.jpg" width="250" height="400" />

### From db
<img src="https://github.com/AlexanderDemchik/MobileTechnologies-Lab1-TicTacToe/raw/master/lab3-2.jpg" width="250" height="400" />
